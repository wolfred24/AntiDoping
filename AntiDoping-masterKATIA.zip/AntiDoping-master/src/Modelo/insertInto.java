
package Modelo;

import Controlador.DBConection;
import static Vista.Main.dbPassword;
import static Vista.Main.dbUser;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class insertInto {
     
    DBConection con = new DBConection(dbUser,dbPassword);
    
      //----------jimmy------------------isertar doctor 
        public String nmedico;
        public String uname;
        public String pass;
        public int permit;
        
       
        
         public void insertar(){
        
         try { 
                 con.conect();
      
     con.stmnt= con.con.createStatement();
    
                  
                  con.stmnt.executeUpdate/*inser delete update*/("INSERT INTO medicos VALUES ('"+0+"','"+nmedico+"','"+uname+"','"+pass+"','"+permit+"')"); 
                              JOptionPane.showMessageDialog(null,"Los valores han sido agregados a la base de datos");
                  } 
                  catch( SQLException e ) { 
                      e.printStackTrace(); 
                  } 
  
              finally { 
                  if ( con != null ) { 
                      try    { 
                          con.close(); 
                          con.stmnt.close(); 
                      } catch( Exception e ) { 
                          System.out.println( e.getMessage()); 
                      } 
                  }}
         
        }
         
        public String name;
        public String licen;
        public String fecha;
        public int genero;
        public String empresa="";
        
         public void insertDonante(){
              try { 
                 con.conect();
      
     con.stmnt= con.con.createStatement();
    
                  
 con.stmnt.executeUpdate("INSERT INTO donantes VALUES ('"+0+"','"+name+"','"+licen+"','"+fecha+"','"
         +genero+"',(select idempresa from empresas where nameempresa='"+empresa+"'))"); 
                              JOptionPane.showMessageDialog(null,"Los valores han sido agregados a la base de datos");
                  } 
                  catch( SQLException e ) { 
                      e.printStackTrace(); 
                  } 
  
              finally { 
                  if ( con != null ) { 
                      try    { 
                          con.close(); 
                          con.stmnt.close(); 
                      } catch( Exception e ) { 
                          System.out.println( e.getMessage()); 
                      } 
                  }}
             
             
         }
         
         
          public int count=0;
           public String empresas[];
            public String idempresas[];
         public void consulta() throws SQLException{
              con.conect();
      
     con.stmnt= con.con.createStatement();
             
             con.RS =con.stmnt.executeQuery("select * from empresas");
            con.RS.last();
             count =con.RS.getRow();
             con.RS.beforeFirst();
              System.out.println("rows "+count);
            empresas=new String[count];
            idempresas=new String[count];
             int i=0;
             while (con.RS.next()) {
                
                 empresas[i]=con.RS.getString("nameempresa");
                 idempresas[i]=con.RS.getString(1);
                 
                   System.out.println("arreglo"+i+" "+idempresas[i]);
                   System.out.println("arreglo2"+i+" "+empresas[i]);
             i++;
                    }
             
            
             
             while(i==empresas.length){
               
                 System.out.println("hola");
                 i++;
             }
             
             
         }
    
}
