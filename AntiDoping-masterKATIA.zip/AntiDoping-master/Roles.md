* Conexion a la base de datos (Cesar)
* Login (Cesar)
* Main Menu (Cesar)
* Frame que muestra la informacion de todas las tablas (Cesar)
* Frame formulario Empresas (miriam)
* Frame formulario Donantes (Jimi)
* Frame formulario Drogas (Miriam)
* Frame formulario Folios (Katia)
* Frame formulario Medicos (Jimi)
* Estilisado (Katia y Miriam)

Formularios:
Van a mostrar los inputs necesarios para ingresar los datos a sus respectivas
tienen que tener un boton de aceptar para insertar los datos en BD
validar campos
mandar mensaje de errror si campos erroneos